

<?php $__env->startSection('content'); ?>

<div class="container" style="width: 50%">
  <h2>Login</h2>
<form action="<?php echo e(url('post-login')); ?>" method="POST" id="logForm">
 
    <?php echo e(csrf_field()); ?>


   <div class="form-label-group">
     <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" >
     <label for="inputEmail">Email address</label>

     <?php if($errors->has('email')): ?>
     <span class="error"><?php echo e($errors->first('email')); ?></span>
     <?php endif; ?>    
   </div> 

   <div class="form-label-group">
     <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password">
     <label for="inputPassword">Password</label>
      
     <?php if($errors->has('password')): ?>
     <span class="error"><?php echo e($errors->first('password')); ?></span>
     <?php endif; ?>  
   </div>

   <button class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Sign In</button>
   <div class="text-center">If you have an account?
     <a class="small" href="<?php echo e(url('registration')); ?>">Sign Up</a></div>
 </form>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jithusaji/Desktop/ordering/foodorderold/resources/views/login.blade.php ENDPATH**/ ?>