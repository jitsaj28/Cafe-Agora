<?php     
$to_email = 'jithusajik@gmail.com';
$subject = 'Testing PHP Mail';
$message = 'This mail is sent using the PHP mail function';
$headers = 'From: noreply jithusajik@gmail.com';
mail($to_email,$subject,$message,$headers);
?>