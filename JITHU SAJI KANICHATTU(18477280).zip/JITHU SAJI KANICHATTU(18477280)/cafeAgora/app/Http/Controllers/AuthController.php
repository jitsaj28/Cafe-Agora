<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Illuminate\Support\Fascades\Mail;
use Validator,Redirect,Response;
Use App\User;
Use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Session;
 
class AuthController extends Controller
{
 //Uer Registration or Login
    public function index()
    {
        return view('login');
    }  

 
    public function registration()
    {
        return view('registration');
    }
   
    //validating user lgin
    public function postLogin(Request $request)
    {
        request()->validate([
        'email' => 'required',
        'password' => 'required',
        ]);
 
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            // Authentication passed...
            return redirect()->intended('/');
        }
        return Redirect::to("login")->withSuccess('Oppes! You have entered invalid credentials');
    }

 //validating the data during registration
    public function postRegistration(Request $request)
    {  
        request()->validate([
        'name' => 'required',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:6',
        ]);
         
        $data = $request->all();
 
        $check = $this->create($data);
       
        
        return Redirect::to("login")->withSuccess('Great! You have Successfully loggedin');
    }

    //Popup message after login 
    public function dashboard()
    {
 
      if(Auth::check()){
        return view('dashboard');
      }
       return Redirect::to("login")->withSuccess('Opps! You do not have access');
    }
 
    //creating new user entries in tabele
    public function create(array $data)
    {
      return User::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'password' => Hash::make($data['password']),
        'phoneno' => $data['phoneno'],
        'address' => $data['address']

      ]);
      //mail after placiing order
      Mail::to($data->email)->send(new WelcomeMail);
    }


     //user logout
    public function logout() {
        Session::flush();
        Auth::logout();
        return Redirect('login');
    }

//View to About us page
    public function about()
    {
        return view('about_us');
    }  
 
 public function contact()
    {
        return view('login');
    }  
 

    


    
}