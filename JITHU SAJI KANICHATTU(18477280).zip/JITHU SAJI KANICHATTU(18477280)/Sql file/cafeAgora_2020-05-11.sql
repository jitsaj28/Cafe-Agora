# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 8.0.19)
# Database: cafeAgora
# Generation Time: 2020-05-10 19:24:47 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table carts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `carts`;

CREATE TABLE `carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pid` int NOT NULL,
  `userid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table catogories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catogories`;

CREATE TABLE `catogories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `catogories` WRITE;
/*!40000 ALTER TABLE `catogories` DISABLE KEYS */;

INSERT INTO `catogories` (`id`, `created_at`, `updated_at`, `name`)
VALUES
	(1,NULL,NULL,'Bakes'),
	(2,NULL,NULL,'Vegetarian'),
	(3,NULL,NULL,'Non-Vegetarian');

/*!40000 ALTER TABLE `catogories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table failed_jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2014_10_12_000000_create_users_table',1),
	(2,'2019_08_19_000000_create_failed_jobs_table',1),
	(3,'2020_04_19_022153_create_catogories_table',1),
	(4,'2020_04_19_055159_add_address_to_users',1),
	(5,'2020_04_19_060051_add_phoneno_to_users',1),
	(6,'2020_04_19_060335_create_carts_table',1),
	(7,'2020_04_19_060651_create_products_table',1),
	(8,'2020_05_10_081932_create_shoppingcart',1);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table products
# ------------------------------------------------------------

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint NOT NULL,
  `quantity` bigint NOT NULL,
  `categoryid` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;

INSERT INTO `products` (`id`, `created_at`, `updated_at`, `name`, `price`, `quantity`, `categoryid`, `image`)
VALUES
	(1,NULL,NULL,'SWISS BIRCHER MUESLI',15,0,2,'swiss_bircher_muesli.jpeg'),
	(2,NULL,NULL,'VIETNAMESE PORK BELLY SALAD',20,0,3,'pork_belly.jpg'),
	(3,NULL,NULL,'SPANISH THREE EGG OMELETTE',17,0,3,'spanish_omlette.jpg'),
	(4,NULL,NULL,'SEASONAL SWEET MUFFINS',3,0,1,'seasonal_sweet_muffin.jpeg'),
	(5,NULL,NULL,'CINNAMON SCROLLS',5,0,1,'cinnamon_scroll.jpg'),
	(6,NULL,NULL,'HUEVOS RANCHEROS (COWBOY EGGS)',20,0,3,'HUEVOS RANCHEROS (COWBOY EGGS).jpg'),
	(7,NULL,NULL,'HUEVOS RANCHEROS (COWBOY TOFU)',20,0,2,'HUEVOS RANCHEROS (COWBOY TOFU).jpeg'),
	(8,NULL,NULL,'AGORA EGGS BENNY(FREE RANGE BACON)',22,0,3,'AGORA EGGS BENNY(FREE RANGE BACON).jpg'),
	(9,NULL,NULL,'AGORA EGGS BENNY(HOUSE SMOKED SALMON)',22,0,3,'AGORA EGGS BENNY(FREE RANGE SALMON).jpg'),
	(10,NULL,NULL,'AGORA EGGS BENNY(ROASTED PORTABELLO)',22,0,2,'AGORA EGGS BENNY(FREE RANGE PORTABELLO).jpg'),
	(11,NULL,NULL,'CARIBBEAN TACOS(FRIED CHICKEN)',18,0,3,'CARIBBEAN TACOS(FRIED CHICKEN).jpg'),
	(12,NULL,NULL,'CARIBBEAN TACOS(CAULIFLOWER)',18,0,2,'CARIBBEAN TACOS(FRIED CAULIFLOWER).jpg'),
	(13,NULL,NULL,'KOREAN STICKY WINGS',18,0,3,'KOREAN STICKY WINGS.jpg'),
	(14,NULL,NULL,'KOREAN STICKY WINGS(CAULIFLOWER)',18,0,2,'KOREAN STICKY WINGS(CAULIFLOWER).jpg'),
	(15,NULL,NULL,'BUFFALO WINGS',16,0,3,'BAFFALO.jpg'),
	(16,NULL,NULL,'BABY BENNY(BACON)',13,0,3,'BABY BENNY(BACON).jpg'),
	(17,NULL,NULL,'BABY BENNY(MUSHROOM)',13,0,2,'BABY BENNY(MUSHROOM).jpg');

/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table shopping
# ------------------------------------------------------------

DROP TABLE IF EXISTS `shopping`;

CREATE TABLE `shopping` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pid` int NOT NULL,
  `userid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneno` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
