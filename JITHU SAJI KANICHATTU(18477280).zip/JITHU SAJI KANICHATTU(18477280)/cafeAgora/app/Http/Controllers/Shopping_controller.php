<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Shopping_controller extends Controller
{
    //
}
