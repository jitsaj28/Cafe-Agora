<?php $__env->startSection('content'); ?>
<style>
.container1{
      background-image: url("<?php echo e(asset('images/2.png')); ?>");
      background-size: cover;
      background-repeat: no-repeat;
      color:white;
      height: 300px;
      margin-bottom: 100;
    }
</style>


  <h2>About Us</h2>

  


     
 

<div class="container1"></div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jithusaji/Desktop/ordering/foodorderold/resources/views/about_us.blade.php ENDPATH**/ ?>