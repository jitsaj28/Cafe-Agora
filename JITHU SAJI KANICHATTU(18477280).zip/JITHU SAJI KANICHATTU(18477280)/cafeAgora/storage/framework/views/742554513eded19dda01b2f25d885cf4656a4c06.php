

<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<div class='useridhidden hidden'><?php echo e(Auth::user()->id); ?></div>
<?php endif; ?>

<div class='col-md-9'>
  
  <div class="row" >
    <h3>Vegetarian<h3>
      <?php if(count($data['items'])>0): ?>
          <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-4">
              <div class="panel panel-primary">
              <div class="panel-heading"><?php echo e($item->name); ?></div>
                <div class="panel-body"><img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"></div>
              <div class="panel-footer"><?php echo e($item->price); ?></div>
              <a href="#" class="addClick">add
                <div class="hidden"><?php echo e($item->id); ?></div>
              </a>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <?php endif; ?>
      
    </div>
</div>





<?php if(Auth::check()): ?>
<div>
  <table class="table table-hover" style="width: 20%">
      <thead>
        <tr>
          <th>Name</th>
          <th>Price</th>
          <th width="1px"></th>
          
        </tr>
      </thead>
      <tbody id="tbody">

      </tbody>
      <tfoot id="tfoot">
          
      </tfoot>
  </table>
</div>
<?php endif; ?>
  <?php $__env->stopSection(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      $userid = $('.container').find('.useridhidden').html();

      //onload
        $sum=0;
        // event.preventDefault();
        $.ajax({
            url:"<?php echo e(url('showcart')); ?>"+"/"+$userid,
            method: "GET",
            // data: {selectedCountry },
            contentType: false,
            dataType: "json",
            success:function(data){
              debugger;
                $('#tbody').html('');
                $('#tfoot').html('');
                data.forEach(element => {
                    $sum = $sum + element.price;
                    $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                });
                
                $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
            },
            error: function(xhr, textStatus, error){
                console.log(xhr.statusText);
                console.log(textStatus);
                console.log(error);
            }

        })
      //onadd
        $(".addClick").click(function(){
            $sum=0;
            var selectedDate = $(this).find('.hidden').html();
            event.preventDefault();
            $.ajax({
                url:"<?php echo e(url('addcart')); ?>"+"/"+selectedDate+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });

      //onremove
      $('#tbody').on('click', '.remove', function () {
          $id = $(this).attr('id');
          $sum=0;
          event.preventDefault();
            $.ajax({
                url:"<?php echo e(url('deletecart')); ?>"+"/"+$id+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  debugger;
                    // alert(data);
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });
    });
    </script>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jithusaji/Desktop/ordering/foodorderold/resources/views/pages/veg.blade.php ENDPATH**/ ?>