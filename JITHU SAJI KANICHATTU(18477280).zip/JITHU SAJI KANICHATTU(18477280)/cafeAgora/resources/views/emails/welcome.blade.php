@component('mail::message')
# Introduction

Thank You for Registering with Us.

@component('mail::button', ['url' => ''])
Button Text
@endcomponent

Thanks Cafe Agora, <br>
{{ config('app.name') }}
@endcomponent
